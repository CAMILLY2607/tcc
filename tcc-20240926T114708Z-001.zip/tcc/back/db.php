<?php
$host = '127.0.0.1';
$user = 'root';
$password = 'root';
$dbname = 'conecta_pinhais';

// Cria a conexão
$conn = new mysqli($host, $user, $password, $dbname);

// Define o charset para evitar problemas com acentos
$conn->set_charset("utf8");

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>